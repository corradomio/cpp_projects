#ifndef _MATERIALBASE__H
#define _MATERIALBASE__H

#include "_helper_.h"

template<typename>
class _MaterialBase_ {
public:
    _MaterialBase_() = default;

};

#endif
