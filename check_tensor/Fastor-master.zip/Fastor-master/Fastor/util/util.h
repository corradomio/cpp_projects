#ifndef UTILS_H
#define UTILS_H

#include "Fastor/util/timeit.h"
#include "Fastor/util/print.h"
#include "Fastor/util/write.h"
#include "Fastor/util/types.h"

#endif
