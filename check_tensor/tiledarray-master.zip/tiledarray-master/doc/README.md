# Building Documentation

* doxygen: `cmake --build <build dir> --target html`
