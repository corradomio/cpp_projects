# Build

* `cmake --build <build dir> --target html`

# Maintainer notes

Bootstrap extensions for Doxygen courtesy of https://github.com/Velron/doxygen-bootstrapped/tree/feature/support-doxygen-1.1.12+ . Requires Doxygen 1.8.12 or later.
