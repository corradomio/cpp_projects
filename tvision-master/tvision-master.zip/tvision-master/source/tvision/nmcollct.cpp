/*------------------------------------------------------------*/
/* filename -       nmcollct.cpp                              */
/*                                                            */
/* defines the streamable name for class TCollection          */
/*------------------------------------------------------------*/
/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *
 */

#define Uses_TCollection
#include <tvision/tv.h>

const char * const _NEAR TCollection::name = "TCollection";
